package com.capgemini.flp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Configuration;

@Configuration
@Entity
@Table(name="feedback")
public class Feedback {
	@Id
	private int product_Id;
	@NotNull
	@Column(name="product_feedback")
	private String feedbackForProduct;
	@Column(name="product_Rating")
	private int productRating;
	@Column(name="customer_emailId")
	private String customerEmailId;
	private int ratingCount;
	private int averageCount;


public  Feedback() {
	
}



public Feedback(int product_Id, String feedbackForProduct, int productRating,
		String customerEmailId, int ratingCount, int averageCount) {
	super();
	this.product_Id = product_Id;
	this.feedbackForProduct = feedbackForProduct;
	this.productRating = productRating;
	this.customerEmailId = customerEmailId;
	this.ratingCount = ratingCount;
	this.averageCount = averageCount;
}



public int getProduct_Id() {
	return product_Id;
}

public void setProduct_Id(int product_Id) {
	this.product_Id = product_Id;
}




public String getFeedbackForProduct() {
	return feedbackForProduct;
}

public void setFeedbackForProduct(String feedbackForProduct) {
	this.feedbackForProduct = feedbackForProduct;
}



public String getCustomerEmailId() {
	return customerEmailId;
}



public void setCustomerEmailId(String customerEmailId) {
	this.customerEmailId = customerEmailId;
}



public int getRatingCount() {
	return ratingCount;
}




public int getProductRating() {
	return productRating;
}



public void setProductRating(int productRating) {
	this.productRating = productRating;
}



public void setRatingCount(int ratingCount) {
	this.ratingCount = ratingCount;
}




public int getAverageCount() {
	return averageCount;
}




public void setAverageCount(int averageCount) {
	this.averageCount = averageCount;
}





}