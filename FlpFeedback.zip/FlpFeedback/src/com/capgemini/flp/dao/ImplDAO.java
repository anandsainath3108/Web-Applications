package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;


import com.capgemini.flp.dto.Feedback;

@Configuration
@Repository
public class ImplDAO implements IntDAO {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Feedback getFeedbackPage(Feedback feedback) {
		// TODO Auto-generated method stub
		entityManager.persist(feedback);
		return feedback;
	}
}
