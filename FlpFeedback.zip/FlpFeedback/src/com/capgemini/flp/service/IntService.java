package com.capgemini.flp.service;

import com.capgemini.flp.dto.Customer_Login;
import com.capgemini.flp.dto.Feedback;

public interface IntService {

	public Feedback getFeedbackPage(Feedback feedback);

}
