package com.capgemini.flp.service;

public interface IReturnGoodsService {

	public String returnGoods(String customer_email_Id, String merchant_email_Id, int product_Id, int product_Quantity);
	
}
