package com.capgemini.ssms.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="ScheduledSessions")
public class SessionScheduleManagementSystemModel {

	@Id
	private Integer number;
	private String sessionName;
	private Integer duration;
	private String faculty;
	private String mode;
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public SessionScheduleManagementSystemModel(Integer number,
			String sessionName, Integer duration, String faculty, String mode) {
		super();
		this.number = number;
		this.sessionName = sessionName;
		this.duration = duration;
		this.faculty = faculty;
		this.mode = mode;
	}
	
	
	
	
}
