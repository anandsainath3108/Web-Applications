package com.capgemini.ssms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.ssms.model.SessionScheduleManagementSystemModel;

@Repository
public class SessionScheduleManagementSystemDAOImpl implements
		ISessionScheduleManagementSystemDAO {

	@PersistenceContext
	EntityManager manager;

	@Override
	public ArrayList<SessionScheduleManagementSystemModel> getAllSessions() {
		// TODO Auto-generated method stub

		ArrayList<SessionScheduleManagementSystemModel> list = new ArrayList<>();
		String jpql = "Select s from ScheduledSessions s";
		TypedQuery<SessionScheduleManagementSystemModel> query = manager
				.createQuery(jpql, SessionScheduleManagementSystemModel.class);
		list = (ArrayList<SessionScheduleManagementSystemModel>) query
				.getResultList();
		return list;
	}

	@Override
	public String findSessionName() {
		// TODO Auto-generated method stub
		String jpql = "Select session.sessionName from ScheduledSessions session where session.sessionName = 1";
		TypedQuery<String> query = manager.createQuery(jpql, String.class);
		String sessionName = query.getSingleResult();
		return sessionName;
	}

}
