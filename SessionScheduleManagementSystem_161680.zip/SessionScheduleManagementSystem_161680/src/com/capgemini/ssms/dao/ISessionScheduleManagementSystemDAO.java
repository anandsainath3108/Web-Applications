package com.capgemini.ssms.dao;

import java.util.ArrayList;

import com.capgemini.ssms.model.SessionScheduleManagementSystemModel;

public interface ISessionScheduleManagementSystemDAO {

	public ArrayList<SessionScheduleManagementSystemModel> getAllSessions();

	public String findSessionName();

}
