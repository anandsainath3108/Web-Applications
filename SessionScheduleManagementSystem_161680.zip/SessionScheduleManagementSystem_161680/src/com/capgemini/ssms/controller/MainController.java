package com.capgemini.ssms.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.ssms.model.SessionScheduleManagementSystemModel;
import com.capgemini.ssms.service.ISessionScheduleManagementSystemService;


@Controller
public class MainController {

	@Autowired
	ISessionScheduleManagementSystemService service;

	@RequestMapping(value="/ScheduledSessions",method=RequestMethod.GET)
	public String displayPage(Model model) {
		String view = "Course Details";
		ArrayList<SessionScheduleManagementSystemModel> list = service.getAllSessions();
		model.addAttribute("courselist", list);
		return view;
	}

	@RequestMapping(value="/Success",method=RequestMethod.POST)
	public String bookingPage(Model model) {
		String view = "";
		String courseName = service.findSessionName();
		model.addAttribute("coursename", courseName);
		view = "Course Registration";
		return view;
	}
}