package com.capgemini.ssms.exception;

public class SessionScheduleManagementSystemException extends Exception {

private static final long serialVersionUID = 1L;
	
	public String msg;
	public SessionScheduleManagementSystemException(String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return msg;
	}
}
