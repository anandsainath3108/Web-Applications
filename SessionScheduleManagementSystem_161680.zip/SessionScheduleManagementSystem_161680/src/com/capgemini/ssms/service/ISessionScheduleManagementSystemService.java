package com.capgemini.ssms.service;

import java.util.ArrayList;

import com.capgemini.ssms.model.SessionScheduleManagementSystemModel;

public interface ISessionScheduleManagementSystemService {
	public ArrayList<SessionScheduleManagementSystemModel> getAllSessions();

	public String findSessionName();
}
