package com.capgemini.ssms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ssms.dao.ISessionScheduleManagementSystemDAO;
import com.capgemini.ssms.model.SessionScheduleManagementSystemModel;

@Service
@Transactional
public class SessionScheduleManagementSystemServiceImpl implements
ISessionScheduleManagementSystemService {

@Autowired
ISessionScheduleManagementSystemDAO dao;
@Override
public ArrayList<SessionScheduleManagementSystemModel> getAllSessions() {
// TODO Auto-generated method stub
return dao.getAllSessions();
}

@Override
public String findSessionName() {
// TODO Auto-generated method stub
return dao.findSessionName();
}

}