package com.cg.timesheet.service;

import com.cg.timesheet.model.TimeSheetUpload;

public interface ITimeSheetService  {
	
	public Integer TimeSheetUpload(TimeSheetUpload ts);
}
