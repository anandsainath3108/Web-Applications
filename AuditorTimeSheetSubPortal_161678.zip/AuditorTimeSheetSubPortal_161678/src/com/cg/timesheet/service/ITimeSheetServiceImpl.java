package com.cg.timesheet.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.timesheet.dao.ITimeSheetDao;
import com.cg.timesheet.model.TimeSheetUpload;
@Service("atsspervice")
@Transactional
public class ITimeSheetServiceImpl implements ITimeSheetService {

	@Autowired
	ITimeSheetDao atsspdao;
	
	@Override
	public Integer TimeSheetUpload(TimeSheetUpload ts) {
		
		Integer id=atsspdao.timeshetupload(ts);
		
		return id;
		
		
		
		
	}

}
