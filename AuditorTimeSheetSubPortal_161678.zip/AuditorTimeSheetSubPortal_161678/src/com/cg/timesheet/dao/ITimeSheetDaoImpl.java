package com.cg.timesheet.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.timesheet.model.TimeSheetUpload;


@Repository
@Transactional
public class ITimeSheetDaoImpl implements ITimeSheetDao {

	

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Integer timeshetupload(TimeSheetUpload ts) {
		em.persist(ts);
		//em.flush(); 
		
		
		return ts.getTsId();
	}

}
