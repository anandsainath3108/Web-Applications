package com.cg.timesheet.dao;

import com.cg.timesheet.model.TimeSheetUpload;

public interface ITimeSheetDao {
	
	public Integer timeshetupload(TimeSheetUpload ts);

}
